package edu.uc.modulocontable.converter;

import edu.uc.modulocontable.modelo2.Autorizaciones;
import edu.uc.modulocontable.facade.AutorizacionesFacade;
import edu.uc.modulocontable.bean.util.JsfUtil;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.convert.FacesConverter;
import javax.inject.Inject;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

@FacesConverter(value = "autorizacionesConverter")
public class AutorizacionesConverter implements Converter {

    @Inject
    private AutorizacionesFacade ejbFacade;

    @Override
    public Object getAsObject(FacesContext facesContext, UIComponent component, String value) {
        if (value == null || value.length() == 0 || JsfUtil.isDummySelectItem(component, value)) {
            return null;
        }
        String nuevoValue = "";
        List<Autorizaciones> autorizaciones = ejbFacade.findAll();
        for (Autorizaciones autorizacione : autorizaciones) {
            if (autorizacione.getNumeroAutorizacion().equals(value)) {
                nuevoValue = autorizacione.getIdAutorizacion() + "";
            }
        }
        return this.ejbFacade.find(Integer.valueOf(nuevoValue));
    }

    java.lang.String getKey(String value) {
        java.lang.String key;
        key = value;
        return key;
    }

    String getStringKey(java.lang.String value) {
        StringBuffer sb = new StringBuffer();
        sb.append(value);
        return sb.toString();
    }

    @Override
    public String getAsString(FacesContext facesContext, UIComponent component, Object object) {
        if (object == null
                || (object instanceof String && ((String) object).length() == 0)) {
            return null;
        }
        if (object instanceof Autorizaciones) {
            Autorizaciones o = (Autorizaciones) object;
            return getStringKey(o.getNumeroAutorizacion());
        } else {
            Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, "object {0} is of type {1}; expected type: {2}", new Object[]{object, object.getClass().getName(), Autorizaciones.class.getName()});
            return null;
        }
    }

}
